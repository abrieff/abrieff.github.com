Assignment 5:

Features implemented:
1. index works properly
2. usersearch works properly
3. POST api works properly

Features partially implemented:
1. GET API does not sort games by score, just returns them.

Features Not Implemented: 
1. No Heroku Connection, app only works locally.
